#pragma once

#define PASSPORT_SETTINGS_FILE_NAME "apps_data/.passport.settings"
